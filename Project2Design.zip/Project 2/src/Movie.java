
public class Movie extends Media{
	
	private String additionalInfo;
	
	public Movie(String title, String year, String additionalInfo){

	}
	
	public String getInfo(){
		
	}
	
	public void setInfo(){
		
	}
	
	public String toString(){
		
	}
}
