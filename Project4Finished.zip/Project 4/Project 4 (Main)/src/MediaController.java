import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;


public class MediaController {

	private ViewMDB theView;
	private DatabaseModel theModel;
	private SeriesEditView seriesEditView;
	private EpisodeEditView episodeEditView;
	private MovieEditView movieEditView;
	private MediaMakerEditView makerEditView;
	private ExportView exportView;
	private ImportView importView;
	private BinaryIOView ioView;
	private FileNamingView fileNameView;
	private EditView addView;

	public MediaController(ViewMDB view, DatabaseModel model, SeriesEditView sev, EpisodeEditView eev, MovieEditView mev, MediaMakerEditView mmev, ExportView ev, BinaryIOView iov, ImportView iv, FileNamingView fnv){
		this.theView = view;
		this.theModel = model;
		this.seriesEditView = sev;
		this.episodeEditView = eev;
		this.movieEditView = mev;
		this.makerEditView = mmev;
		this.exportView = ev;
		this.ioView = iov;
		this.importView = iv;
		this.fileNameView = fnv;
		addView = new EditView();
		
		seriesEditView.registerCancelButtonListener(new CancelListener());
		episodeEditView.registerCancelButtonListener(new CancelListener());
		movieEditView.registerCancelButtonListener(new CancelListener());
		makerEditView.registerCancelButtonListener(new CancelListener());
		exportView.registerCancelButtonListener(new CancelListener());
		ioView.registerCancelListener(new CancelListener());
		importView.registerCancelButtonListener(new CancelListener());
		fileNameView.registerCancelButtonListener(new CancelListener());
		
		
		addView.registerConfirmButtonListener(new ConfirmAddButtonListener());
		
		this.importView.registerConfirmButtonListener(new ImportViewConfirmButtonListener());
		
		this.fileNameView.registerConfirmButtonListener(new FileNamingViewConfirmButtonListener());
		
		// Register the save/load buttons in the BinaryIOView
		this.ioView.registerLoadButtonListener(new LoadBinaryIOListener());
		this.ioView.registerSaveButtonListener(new SaveBinaryIOListener());
		this.ioView.registerCancelListener(new CancelListener());
		
		// Register the confirm button on the edit views
		this.seriesEditView.registerConfirmButtonListener(new ConfirmEditButtonListener());
		this.episodeEditView.registerConfirmButtonListener(new ConfirmEditButtonListener());
		this.movieEditView.registerConfirmButtonListener(new ConfirmEditButtonListener());
		this.makerEditView.registerConfirmButtonListener(new ConfirmEditButtonListener());
		
		
		
		// Register the 'Export as Text' and 'Export as Binary File' buttons in ExportView
		this.exportView.registerBinaryButtonListener(new ExportAsBinaryListener());
		this.exportView.registerTextButtonListener(new ExportAsTextListener());
		
		// Register all buttons on the main program view
		this.theView.registerActorsRB(new ActorsRadioButtonListener());
		this.theView.registerDirectorsRB(new DirectorsRadioButtonListener());
		this.theView.registerProducersRB(new ProducersRadioButtonListener());
		this.theView.registerMakersRB(new MakersRadioButtonListener());
		this.theView.registerMediaRB(new MediaRadioButtonListener());
		this.theView.registerMovieRB(new MoviesRadioButtonListener());
		this.theView.registerSeriesRB(new SeriesRadioButtonListener());
		this.theView.registerEpisodesRB(new EpisodesRadioButtonListener());
		this.theView.registerPieChartListener(new PieChartListener());
		this.theView.registerHistogramListener(new HistogramListener());
		this.theView.registerDeleteListener(new DeleteListener());
		this.theView.registerAddListener(new AddListener());
		this.theView.registerEditListener(new EditListener());
		this.theView.registerClearListener(new ClearListener());
		this.theView.registerClearAllListener(new ClearAllListener());
		this.theView.registerImportListener(new ImportListener());
		this.theView.registerExportListener(new ExportListener());
		this.theView.registerLoadListener(new LoadListener());
		this.theView.registerSaveListener(new SaveListener());


	}

	class MediaRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	 

			if(theView.media.isSelected()){
				theView.populateListModel();
			}

		} 
	}

	class MoviesRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	
			if(theView.movies.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class SeriesRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	 
			if(theView.series.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class EpisodesRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	
			if(theView.episodes.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class MakersRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	 
			if(theView.makers.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class ActorsRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	 
			if(theView.actors.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class DirectorsRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	 
			if(theView.directors.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class ProducersRadioButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;	 	 
			if(theView.producers.isSelected()){
				theView.populateListModel();
			}
		} 
	}

	class PieChartListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;

			MediaPerson person = (MediaPerson) theView.mediaOutput.getSelectedValue();

			JFrame frame = new JFrame();
			frame.setTitle(person.getName());
			PieChartJ pc = new PieChartJ(person);
			frame.getContentPane().add(pc);
			frame.setSize(1000, 1000);
			frame.setVisible(true);	


		}
	}
	
	class HistogramListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;


			MediaPerson person = (MediaPerson) theView.mediaOutput.getSelectedValue();

			JFrame frame = new JFrame();
			frame.setSize(1000, 1000);
			frame.setTitle(person.getName());
			histogram hs = new histogram(person);
			frame.add(hs);
			frame.setVisible(true);


		}

	}
	class DeleteListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;
			
			Object selection = theView.mediaOutput.getSelectedValue();
			theView.listModel.remove(theView.mediaOutput.getSelectedIndex());

			

			if(selection instanceof Media ){
				theModel.mdb.removeMedia(((Media)selection));
			}
			else if(selection instanceof MediaPerson){
				theModel.mpdb.removePerson((MediaPerson)selection);
			}
			else{
				System.out.println("Could not remove selected object.");
			}

			theView.repaint();		 

		}

	}
	class AddListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;
			
			// get which button is selected. Note: a specific, not generic, radio button must be selected
			// pop up appropriate EditView w/ blank text fields
			if(theView.movies.isSelected()){
				movieEditView.setVisible(true);
			}
			else if(theView.series.isSelected()){
				seriesEditView.setVisible(true);
			}
			else if(theView.episodes.isSelected()){
				episodeEditView.setVisible(true);
			}
			else if(theView.actors.isSelected() || theView.directors.isSelected() || theView.producers.isSelected() ){
				makerEditView.setVisible(true);
			}
			else{
				JOptionPane.showMessageDialog(null, "Please select a specific option from the radio button menu \n"
						+ "in order to add a new entry of that type.");
			}
		}

	}
	class EditListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;
			
			// get which button is selected
			// pop up appropriate EditView w/ populated text fields
			if(theView.movies.isSelected()){
				movieEditView.tfTitle.setText((((Movie) theView.mediaOutput.getSelectedValue()).getTitle()) );
				movieEditView.tfYear.setText((((Movie) theView.mediaOutput.getSelectedValue()).getYear()) );
				movieEditView.setVisible(true);
			}
			else if(theView.series.isSelected()){
				seriesEditView.tfTitle.setText((((TVSeries) theView.mediaOutput.getSelectedValue()).getTitle()) );
				seriesEditView.tfYear.setText((((TVSeries) theView.mediaOutput.getSelectedValue()).getYear()) );
				seriesEditView.setVisible(true);
			}
			else if(theView.episodes.isSelected()){
				episodeEditView.tfTitle.setText((((TVEpisode) theView.mediaOutput.getSelectedValue()).getEpisodeName()) );
				episodeEditView.tfYear.setText((((TVEpisode) theView.mediaOutput.getSelectedValue()).getYearAired()) );
				episodeEditView.tfEpiNum.setText((((TVEpisode) theView.mediaOutput.getSelectedValue()).getSeasAndEpNums()) );
				episodeEditView.setVisible(true);
			}
			else if(theView.actors.isSelected() || theView.directors.isSelected() || theView.producers.isSelected() ){
				makerEditView.tfTitle.setText((((MediaPerson) theView.mediaOutput.getSelectedValue()).getName()) );
				makerEditView.tfYear.setText((((MediaPerson) theView.mediaOutput.getSelectedValue()).getProfession()) );
				makerEditView.setVisible(true);
			}
			else if(theView.media.isSelected()){
				if(theView.mediaOutput.getSelectedValue() instanceof Movie){
					movieEditView.tfTitle.setText((((Movie) theView.mediaOutput.getSelectedValue()).getTitle()) );
					movieEditView.tfYear.setText((((Movie) theView.mediaOutput.getSelectedValue()).getYear()) );
					movieEditView.setVisible(true);
				}
				else if(theView.mediaOutput.getSelectedValue() instanceof TVSeries){
					seriesEditView.tfTitle.setText((((TVSeries) theView.mediaOutput.getSelectedValue()).getTitle()) );
					seriesEditView.tfYear.setText((((TVSeries) theView.mediaOutput.getSelectedValue()).getYear()) );
					seriesEditView.tfRY.setText((((TVSeries) theView.mediaOutput.getSelectedValue()).getRunningYears()) );
					seriesEditView.setVisible(true);
				}
				else if(theView.mediaOutput.getSelectedValue() instanceof TVEpisode){
					episodeEditView.tfTitle.setText((((TVEpisode) theView.mediaOutput.getSelectedValue()).getEpisodeName()) );
					episodeEditView.tfYear.setText((((TVEpisode) theView.mediaOutput.getSelectedValue()).getYearAired()) );
					episodeEditView.tfEpiNum.setText((((TVEpisode) theView.mediaOutput.getSelectedValue()).getSeasAndEpNums()) );
					episodeEditView.setVisible(true);
				}
				
				theView.populateListModel();
			}
		}
	}
	
	class ClearListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;
			
			

			if(theView.movies.isSelected()){
				theModel.mdb.movieDatabase = new ArrayList<Movie>();
				theView.repaint();
			}
			else if(theView.series.isSelected()){
				theModel.mdb.tvDatabase = new ArrayList<TVSeries>();
				theView.listModel.clear();
				theView.repaint();
			}
			else if(theView.episodes.isSelected()){
				for(TVSeries series: theModel.mdb.tvDatabase){
					series = new TVSeries(series, true); // special constructor for removing all episodes from a given series
				}
				theView.listModel.clear();
				theView.repaint();
			}
			else if(theView.actors.isSelected() || theView.directors.isSelected() || theView.producers.isSelected() || theView.makers.isSelected()){ //TODO: lazy, false functionality. fixme
				theModel.mpdb.mpdb.clear();
				theView.listModel.clear();
				theView.repaint();
			}
			
		}

	}

	class ClearAllListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;

			theModel.mdb = new MediaDatabase();
			theModel.mpdb = new MediaPersonDatabase();

			theView.listModel.removeAllElements();
			theView.mediaOutput.removeAll();
			theView.repaint();

		}

	}

	class ExportListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;

			exportView.setVisible(true);
			
		}

	}
	class ImportListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;
			
			 importView.setVisible(true);
			
		}

	}
	class LoadListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;

			ioView.setVisible(true);

		}

	}
	class SaveListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if (theModel == null)
				return;

			ioView.setVisible(true);

		}

	}
	
	class ExportAsTextListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			if (theModel == null)
				return;
			
			fileNameView.setVisible(true);
			
		}
		
	}
	
	class ExportAsBinaryListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			if (theModel == null)
				return;
			
			try {
				theModel.saveDatabase(ioView.jtfFileName.getText());
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "The current database could not be saved using that name.");
			}
			finally{
				theView.repaint();
				ioView.setVisible(false);
			}
			
		}
		
	}
	
	// Confirm button for the Edit views
	class ConfirmAddButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			

			if(theView.movies.isSelected()){
				theModel.mdb.movieDatabase.add(new Movie(movieEditView.tfTitle.getText(), movieEditView.tfYear.getText(), ""));
				theView.populateListModel();
				theView.repaint();
			}
			else if(theView.series.isSelected()){
			//	seriesEditView
				theModel.mdb.tvDatabase.add(new TVSeries(seriesEditView.tfTitle.getText(), seriesEditView.tfYear.getText(), seriesEditView.tfRY.getText()));
				theView.repaint();
			}
			else if(theView.episodes.isSelected()){
			//	episodeEditView
				((TVSeries) theModel.mdb.searchTVTitleExact(((TVSeries) theView.mediaOutput.getSelectedValue()).getTitle(), false).get(0)).addEpisode(new TVEpisode(episodeEditView.tfTitle.getText(), episodeEditView.tfYear.getText(), episodeEditView.tfEpiNum.getText(), ((TVSeries) theView.mediaOutput.getSelectedValue()).getTitle()));
				theView.repaint();
			}
			else if(theView.actors.isSelected() || theView.directors.isSelected() || theView.producers.isSelected() ){
			//	makerEditView
				theModel.mpdb.addPerson(new MediaPerson(makerEditView.tfTitle.getText(), makerEditView.tfYear.getText()));
			}
			else{
				JOptionPane.showMessageDialog(null, "Please select a specific option from the radio button menu \n"
						+ "in order to add a new entry of that type.");
			}
			
			movieEditView.setVisible(false);
			seriesEditView.setVisible(false);
			episodeEditView.setVisible(false);
			makerEditView.setVisible(false);
			
		}
		
	}
	
	class ConfirmEditButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			

			// update entry in database
			int selection = theView.getSelectedRadioButton();
			
			if(selection <= 2){
				theModel.mdb.removeMedia((Media) theView.mediaOutput.getSelectedValue());
				if(selection == 1)
					theModel.mdb.addMedia(new Movie(movieEditView.tfTitle.getText(), movieEditView.tfYear.getText(), ""));
				else if(selection == 2){
					theModel.mdb.addMedia(new TVSeries(seriesEditView.tfTitle.getText(), seriesEditView.tfYear.getText(), seriesEditView.tfRY.getText()));
				}
			}
			else if(selection >= 4){
				MediaPerson person = (MediaPerson) theView.mediaOutput.getSelectedValue();
				person.setName(makerEditView.tfTitle.getText());
				person.setProfession(makerEditView.tfYear.getText());
			}
			
			

			theView.populateListModel();
			theView.repaint();
			
			movieEditView.setVisible(false);
			seriesEditView.setVisible(false);
			episodeEditView.setVisible(false);
			makerEditView.setVisible(false);
			
		}
		
	}
	
	class SaveBinaryIOListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			
			try {
				theModel.saveDatabase(ioView.jtfFileName.getText());
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "The current database could not be saved using that name.");
			}
			finally{
				ioView.setVisible(false);
				theView.repaint();
			}
			
		}
		
	}
	
	class LoadBinaryIOListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			
			try {
				theModel = new DatabaseModel(ioView.jtfFileName.getText());
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "An error has occurred. \nPlease ensure the name of the file you entered is correct.");
			}
			finally{
				ioView.setVisible(false);
				theView.repaint();
			}
		}
		
	}
	
	class ImportViewConfirmButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			
			FileReader fr = null;
			
			try {
				System.out.println(importView.fileCB.getSelectedItem().toString());
				fr = new FileReader(importView.fileCB.getSelectedItem().toString());
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Please ensure the name and contents\nof the text file match the selected data type.");
			}
			BufferedReader br = new BufferedReader(fr);
			
			if(importView.actors.isSelected()){
				try {
					DatabaseModel.readPeopleToMDb(br, theModel.mpdb, theModel.mdb, "acting");
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Import failed.");
				}
			}
			else if(importView.directors.isSelected()){
				try {
					DatabaseModel.readPeopleToMDb(br, theModel.mpdb, theModel.mdb, "directing");
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Import failed.");
				}
			}
			else if(importView.producers.isSelected()){
				try {
					DatabaseModel.readPeopleToMDb(br, theModel.mpdb, theModel.mdb, "producing");
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Import failed.");
				}
			}
			else if(importView.movies.isSelected()){
				try {
					DatabaseModel.readMoviesToMDb(br, theModel.mdb);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Import failed.");
				}
			}
			else if(importView.series.isSelected()){
				try {
					DatabaseModel.readTVToMDb(br, theModel.mdb);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Import failed.");
				}
			}
			else{
				JOptionPane.showMessageDialog(null, "Import failed. Ensure your file name matches the selection.");
			}
			importView.setVisible(false);
		}
		
		
		
	}
	
	class FileNamingViewConfirmButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			
			try{
			FileWriter filer = new FileWriter(fileNameView.jtfFileName.getText());
			BufferedWriter bw = new BufferedWriter(filer);
			for(int i=0; i<theView.mediaOutput.getMaxSelectionIndex(); i++){
				bw.write(theView.mediaOutput.getSelectedValue().toString());
				bw.write("\n");
			}
			bw.close();
			}
			catch(IOException e){
				JOptionPane.showMessageDialog(null, "An error occurred while writing the file.");
			}
			finally{
				fileNameView.jtfFileName.setText("");
				exportView.setVisible(false);
			}
			
			fileNameView.setVisible(false);
		}
	}
	
	class CancelListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			ioView.setVisible(false);
			seriesEditView.setVisible(false);
			episodeEditView.setVisible(false);
			movieEditView.setVisible(false);
			makerEditView.setVisible(false);
			importView.setVisible(false);
			exportView.setVisible(false);
			fileNameView.setVisible(false);
		}
		
	}

	public void setModel(DatabaseModel model){
		this.theModel = model;
	}

	public void setView(ViewMDB view){
		this.theView = view;
	}



}