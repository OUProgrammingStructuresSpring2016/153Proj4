import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class FileNamingView extends JFrame implements ActionListener{

	/**Confirms user's option */
	public Button confirm = new Button("Confirm");
	
	/**Cancel's user's input */
	public Button cancel = new Button("Cancel");
	
	public JTextField jtfFileName = new JTextField();
	private JLabel label = new JLabel("Enter the name of the file: ");
	
	public FileNamingView(){
		
		JPanel ccButtons = new JPanel();
		ccButtons.add(confirm,BorderLayout.WEST);
		ccButtons.add(cancel, BorderLayout.EAST);
		ccButtons.add(label);
		
		this.setTitle("File Name");
		this.add(label, BorderLayout.NORTH);
		this.add(jtfFileName, BorderLayout.CENTER);
		
		this.add(ccButtons, BorderLayout.SOUTH);
		this.setSize(300, 300);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public void registerConfirmButtonListener(ActionListener al){
		confirm.addActionListener(al);
	}
	
	public void registerCancelButtonListener(ActionListener al){
		cancel.addActionListener(al);
	}

}
