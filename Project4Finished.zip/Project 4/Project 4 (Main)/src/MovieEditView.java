import java.awt.event.ActionListener;
	
/**Edit view for Movie entries when user picks Edit option
	 * to edit an entry
	  */
public class MovieEditView extends EditView  implements ActionListener{


	
	public MovieEditView(){
		setTitle("Movie Edit View");
		
	}
	
}