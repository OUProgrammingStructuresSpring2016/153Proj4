import java.util.ArrayList;


public class MediaPerson{

	private String name;
	
	private String profession;
	
	private ArrayList<String> works;
	
	/**
	 * Constructs a new instance of MediaPerson.
	 * @param name	The name to give the MediaPerson
	 * @param profession	The job(s) of the MediaPerson
	 */
	MediaPerson(String name, String profession){
		
	}
	/**
	 * @return This MediaPerson's name
	 */
	public String getName(){
		
	}
	/**
	 * @param name The new name to give this MediaPerson
	 */
	public void setName(String name){
		
	}
	
	/**
	 * @return This MediaPerson's profession(s)
	 */
	public String getProfession(){
		
	}
	
	/**
	 * @param profession The new profession(s) to give this MediaPerson
	 */
	public void setProfession(String profession){
		
	}
	
	/**
	 * @return The ArrayList containing this MediaPerson's works
	 */
	public ArrayList<String> getWorks(){
		
	}
	
	/**
	 * Adds a work to that the MediaPerson created/participated in.
	 */
	public void addWork(){
		
	}
	/**
	 * @return The String representing this MediaPerson's works, as per project specifications
	 */
	public String worksToString(){
		
	}
	
	/**
	 * @return The String representing this MediaPerson, including works, as per project specifications
	 */
	public String toString(){
		
	}
}
