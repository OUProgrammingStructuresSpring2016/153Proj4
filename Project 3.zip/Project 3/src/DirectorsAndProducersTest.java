import static org.junit.Assert.*;

import org.junit.Test;

public class DirectorsAndProducersTest {

	@Test
	public void testDirectorsAndProducers() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetCredits() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCredits() {
		fail("Not yet implemented");
	}

}
