
public class Actors extends MediaMakers{
	//private fields for DirectorsAndProducers class
	//credits for these media makers
	private String credits;
	
	//Constructor for class
	public Actors(){
	}
	
	/**
	 * Sets the credits. Mutator method
	 * <P>
	 * Algorithm:<br>
	 * 1. Sets the credits of the actor to credits. <br>
	 * </P>
	 * @param 	credits		credits the actor has.
	 */
	public void setCredits(String credits){
	}
	
	/**
	 * Gets credits of the actor. Accessor method
	 * <P>
	 * Algorithm:<br>
	 * 1. Gets the credits.<br>
	 * </P>
	 * @return  String		Credits of actor. 
	 */
	public String getCredits(){
		return null;
		
	}
}
