import static org.junit.Assert.*;

import org.junit.Test;

public class SeriesTest {

	@Test
	public void testSeries() {
		fail("Not yet implemented");
	}

}
