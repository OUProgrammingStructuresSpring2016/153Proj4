import static org.junit.Assert.*;

import org.junit.Test;

public class MediaMakersTest {

	@Test
	public void testMediaMakers() {
		fail("Not yet implemented");
	}

}
