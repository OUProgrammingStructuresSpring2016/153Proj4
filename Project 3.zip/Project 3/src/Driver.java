
/**
 * Project #1
 * CS 2334, Section 011
 * March 07, 2016
 * <P>
 *The driver class initially runs the entire program and 
 *enacts the user's interface. The Driver handles everything
 *and initiates all the other methods. 
 * </P>
 * @version 1.0
 */
public class Driver {
	
	
	public void graphicsDisplay(){
		
	}
	public static void main(String[] args){
	}

}
