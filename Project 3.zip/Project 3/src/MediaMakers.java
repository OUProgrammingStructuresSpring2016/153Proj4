
public class MediaMakers extends Database{
	//private fields
	//last name for media maker
	private String lastName;
	//first name for media maker
	private String firsName;
	
	//default constructor for MediaMaker class
	public MediaMakers(){
		
	}

	/**
	 * Sets the last name to media make. Mutator method
	 * <P>
	 * Algorithm:<br>
	 * 1. Sets the last name of the media maker. <br>
	 * </P>
	 * @param 	name		Last name of the media maker
	 */
	public void setLastName(String name){
		
	}

	/**
	 * Sets the first name to media make. Mutator method
	 * <P>
	 * Algorithm:<br>
	 * 1. Sets the first name of the media maker. <br>
	 * </P>
	 * @param 	name		First name of the media maker
	 */
	public void setFirstName(String name){
		
	}
	
	/**
	 * Gets the media makers last name. Accessor method
	 * <P>
	 * Algorithm:<br>
	 * 1. Gets the last name of the media maker. <br>
	 * </P>
	 * @return  String			Media maker's last name
	 */
	public String getLastName(){
		return null;
	}
	
	/**
	 * Gets the media makers first name. Accessor method
	 * <P>
	 * Algorithm:<br>
	 * 1. Gets the first name of the media maker. <br>
	 * </P>
	 * @return  String			Media maker's first name
	 */
	public String getFirstName(){
		return null;
	}
}
