
public class DirectorsAndProducers extends MediaMakers{
	//private fields for DirectorsAndProducers class
	//credits for these media makers
	private String credits;
	
	//Constructor for class
	public DirectorsAndProducers(){
	}
	
	/**
	 * Sets the credits. Mutator method
	 * <P>
	 * Algorithm:<br>
	 * 1. Sets the credits of the media makers to credits. <br>
	 * </P>
	 * @param 	credits		credits the makers have.
	 */
	public void setCredits(String credits){
	}
	
	/**
	 * Gets credits of the makers. Accessor method
	 * <P>
	 * Algorithm:<br>
	 * 1. Gets the credits.<br>
	 * </P>
	 * @return  String		Credits of media makers. 
	 */
	public String getCredits(){
		return null;
		
	}
}
