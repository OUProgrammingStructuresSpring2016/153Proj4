import static org.junit.Assert.*;

import org.junit.Test;

public class EpisodeTest {

	@Test
	public void testEpisode() {
		fail("Not yet implemented");
	}

}
