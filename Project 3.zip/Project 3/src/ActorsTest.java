import static org.junit.Assert.*;

import org.junit.Test;

public class ActorsTest {

	@Test
	public void testActors() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetCredits() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCredits() {
		fail("Not yet implemented");
	}

}
