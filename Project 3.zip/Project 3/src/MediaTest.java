import static org.junit.Assert.*;

import org.junit.Test;

public class MediaTest {

	@Test
	public void testMedia() {
		fail("Not yet implemented");
	}

}
