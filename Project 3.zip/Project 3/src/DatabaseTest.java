import static org.junit.Assert.*;

import org.junit.Test;

public class DatabaseTest {

	@Test
	public void testDatabase() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddMedia() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMovieTitleExact() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMovieTitlePartial() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMovieYear() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMovieBoth() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchTVTitleExact() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchTVTitlePartial() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchTVYear() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchTVBoth() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchMediaMakers() {
		fail("Not yet implemented");
	}

	@Test
	public void testReadFile() {
		fail("Not yet implemented");
	}

	@Test
	public void testWriteFile() {
		fail("Not yet implemented");
	}

	@Test
	public void testCompare() {
		fail("Not yet implemented");
	}

	@Test
	public void testCompareTo() {
		fail("Not yet implemented");
	}

}
